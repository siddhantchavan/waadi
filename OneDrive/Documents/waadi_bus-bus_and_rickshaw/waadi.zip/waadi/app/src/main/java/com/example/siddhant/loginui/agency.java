package com.example.siddhant.loginui;
import java.util.List;

public class agency {
    private String ownername;
    private String agencyname;

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public String getAgencyname() {
        return agencyname;
    }

    public void setAgencyname(String agencyname) {
        this.agencyname = agencyname;
    }

    public String getAgencyaddress() {
        return agencyaddress;
    }

    public void setAgencyaddress(String agencyaddress) {
        this.agencyaddress = agencyaddress;
    }

    public String getAgencyphone() {
        return agencyphone;
    }

    public void setAgencyphone(String agencyphone) {
        this.agencyphone = agencyphone;
    }

    private String agencyaddress;
    private String agencyphone;



}