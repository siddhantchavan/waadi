package com.example.siddhant.loginui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class agency_dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agency_dashboard);
    }
}
